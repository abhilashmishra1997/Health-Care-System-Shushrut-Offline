# Shushrut
Shushrut is a multi-purpose application, which aims at providing the best health carefacilities to its users, free of cost. It is an attempt to integrate 3 widely different, but equally important areas of health care, namely:

1. Automation in identification of a patient’s disease, without consulting a doctor directly.

2. Providing proper medication for a particular disease (Allopathic, Herbal, Homeopathic, Traditional and home-made remedies)

3. Providing proper details of doctors to be consulted, for cross-consultation and for situations needing immediate attention.

Shushrut is an honest endeavor by Abhilash Mishra, Soumya Ranjan Patel and Dr. Rakesh Mohanty, Associate Professor of VSSUT, Burla, Sambalpur, Odisha(Guiding Professor)(E-mail:rakesh.iitmphd@gmail.com), to make the world a better place.
